export class Complaints {
   ticketId: number;
   customerEmail: string;
   pincode: string;
   complaint: string;
   status: string = 'raised';
}
