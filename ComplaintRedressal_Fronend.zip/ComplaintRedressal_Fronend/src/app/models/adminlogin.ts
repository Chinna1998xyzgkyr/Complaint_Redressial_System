export class Adminlogin {
   id: string;
   password: string;
}
